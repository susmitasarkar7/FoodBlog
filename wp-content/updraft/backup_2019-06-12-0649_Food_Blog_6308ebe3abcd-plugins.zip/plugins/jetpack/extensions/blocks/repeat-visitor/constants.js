export const CRITERIA_AFTER = 'after-visits';
export const CRITERIA_BEFORE = 'before-visits';
export const DEFAULT_THRESHOLD = 3;
export const COOKIE_NAME = 'jp-visit-counter';
export const MAX_COOKIE_AGE = 6 * 30 * 24 * 60 * 60; // 6 months

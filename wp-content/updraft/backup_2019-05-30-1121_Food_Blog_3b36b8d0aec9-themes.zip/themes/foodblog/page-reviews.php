<?php
/**
 * Template Name : Reviews Page
 */

get_header();
?>


<?php
get_footer();
?>